<?php
session_start();
include_once("conexao.php");
$year=$_POST ["ano"];
$number=$_POST ["numero"];
$title=$_POST ["titulo"];
$result=$_POST ["resultado"];
$object=$_POST["objetivo"];
$theme=$_POST ["tema"];
$proposts=$_POST ["envolve_proposta"];
$cordinator=$_POST ["coordenador"];
$result_cadastro="INSERT INTO cadastro_acao(ano, numero, titulo, resultado, objetivo, tema, envolve_proposta, coordenador)
 Values('$year','$number','$title','$result','$object','$theme','$proposts','$cordinator')";
$resultado=mysqli_query($con,$result_cadastro);
if (mysqli_insert_id($con)){
     echo "<script>
                    alert('Ação cadastrada com sucesso!');
                    window.location.href='http://localhost/project/cadastro_acao.php';
                    </script>";
}else{
   echo "<script>
                    alert('A Ação não foi cadastrada.');
                    window.location.href='http://localhost/project/cadastro_acao.php';
                    </script>";
}
?>

