<?php
include_once("conexao.php");
$result_events = "SELECT id, title, color, start, end FROM agenda";
$resultado_events = mysqli_query($con, $result_events);
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset='utf-8'>
		<title>Agenda</title>
		<link rel="stylesheet" type="text/css" href="css/cadastro_acao.css">
	    <link href='css/fullcalendar.min.css' rel='stylesheet' />
	    <link href='css/fullcalendar.print.min.css' rel='stylesheet' media='print' />
	    <link rel="stylesheet" type="text/css" href="css/cadastro_acao.css">
		<script src='js/moment.min.js'></script>
		<script src='js/jquery.min.js'></script>
		<script src='js/fullcalendar.min.js'></script>
		<script src='locale/pt-br.js'></script>
		<script>
			$(document).ready(function() {
				$('#calendar').fullCalendar({
					header: {
						left: 'prev,next today',
						center: 'title',
						right: 'month,agendaWeek,agendaDay'
					},
					defaultDate: Date(),
					navLinks: true,
					editable: true,
					eventLimit: true, 
					events: [
						<?php
							while($row_events = mysqli_fetch_array($resultado_events)){
								?>
								{
								id: '<?php echo $row_events['id']; ?>',
								title: '<?php echo $row_events['title']; ?>',
								start: '<?php echo $row_events['start']; ?>',
								end: '<?php echo $row_events['end']; ?>',
								color: '<?php echo $row_events['color']; ?>',
								},<?php
							}
						?>

					]
				});
			});
		</script>
		<?php 
        session_start();
        if((!isset($_SESSION['matricula'])==true) and (!isset($_SESSION['senha'])==true))
        {
            unset($_SESSION['matricula']);
            unset($_SESSION['senha']);
                echo "<script>
                    alert('Acesso permitido somente a usuário logado');
                    window.location.href='login.php';
                    </script>";
        }
        $logado=$_SESSION['matricula'];
    ?> 
	</head>
	<body>
		<div id="menu">
			
			<ul>
				<img src="logo.png"/>
				<li><a href="http://localhost/project/cadastro_acao.php">Cadastrar Ação</a></li>
				<li><a href="http://localhost/project/result_acoes.php">Ações</a></li>
				<li><a href="http://localhost/project/agenda.php">Agenda</a></li>
				<li><a href="http://localhost/project/cadastro_usuario.php">Cadastrar usuários</a></li>
				<li><a href="http://localhost/project/login.php"><img src="sair-branco.png"/></a></li>
			</ul>
		</div>
		<div id='calendar'></div>
		<a href="event.php"id="new"> Cadastrar novo evento</a>

	</body>
</html>
