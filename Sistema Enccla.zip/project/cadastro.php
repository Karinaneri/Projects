<?php
session_start();
include_once("conexao.php");
$matric=$_POST ["matricula"];
$name=$_POST ["nome"];
$role=$_POST ["cargo"];
$password=$_POST ["senha"];
$confirm=$_POST ["confirmar_senha"];
$result_cadastro="INSERT INTO cadastro_usuario (matricula,nome,cargo,senha,confirmar_senha)
 Values('$matric','$name','$role','$password','$confirm')";
$resultado=mysqli_query($con, $result_cadastro);
if (mysqli_insert_id($con)){
    $_SESSION['mensagem']="<p style='color:#FF0000;'>Usuário não cadastrado.<p>";
    header("Location: http://localhost/project/cadastro_usuario.php");
}else{
    $_SESSION['mensagem']="<p style='color:#00FF00;'>Usuário cadastrado com sucesso!<p>";
    header("Location: http://localhost/project/cadastro_usuario.php");
}
if($password!=$confirm){
$_SESSION['mensagem']="<p style='color:#FF0000;'>As senhas informadas não coincidem.Tentar novamente.<p>";
header("Location: http://localhost/project/cadastro_usuario.php");
}
?>
$login
