<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Cadastrar de Ação</title>
		<link rel="stylesheet" type="text/css" href="css/cadastro_acao.css">
		<?php 
        session_start();
        if((!isset($_SESSION['matricula'])==true) and (!isset($_SESSION['senha'])==true))
        {
            unset($_SESSION['matricula']);
            unset($_SESSION['senha']);
                echo "<script>
                    alert('Acesso permitido somente a usuário logado');
                    window.location.href='login.php';
                    </script>";
        }
        $logado=$_SESSION['matricula'];
    ?> 
	</head>
	<body>
		
		<div id="menu">
			<ul>
				<img src="logo.png"/>
				<li><a href="http://localhost/project/cadastro_acao.php">Cadastrar Ação</a></li>
				<li><a href="http://localhost/project/result_acoes.php">Ações</a></li>
				<li><a href="http://localhost/project/agenda.php">Agenda</a></li>
				<li><a href="http://localhost/project/cadastro_usuario.php">Cadastrar usuários</a></li>
				<li><a href="http://localhost/project/login.php"><img src="sair-branco.png"/></a></li>
			</ul>
		</div>
		
		<h1>Cadastro de Ação</h1>	
		<div class="container">
		<form id="form" method="POST" action="acoes.php">
		<fieldset>
			<p>
				<label id="padrao">Ano</label><br>
		        <select name="ano">
                    <option>2010</option>
					<option>2011</option>
					<option>2012</option>
					<option>2013</option>
					<option>2014</option>
					<option>2015</option>
					<option>2016</option>
					<option>2017</option>
					<option>2018</option>
					<option>2019</option>
					<option>2020</option>
				</select>		
			</p>
			
            <p>
                <label id="padrao">Número</label><br>
                <input type="text" class="box" name="numero">
            </p>
			
			 <p>
                <label id="padrao">Título</label><br>
				 <textarea id="box-title" name="titulo"></textarea>
            </p>
			
			 <p>
                <label id="padrao">Resultado</label><br>
                 <textarea id="result" name="resultado"></textarea>
            </p> 
			
			 <p>
                <label id="padrao">Objetivo estratégico</label><br>
                <input type="text" class="box-obj" name="objetivo">
            </p>
			
			 <p>
                <label id="padrao">Temática</label><br>
                <input type="text" class="box-tem" name="tema">
            </p>
			
			<p>
                <label id="padrao">Envolve proposta normativa?</label>
			<br><input type="radio" class="propost" value="Sim" name="envolve_proposta">Sim  <input type="radio" class="propost" value="Não" name="envolve_proposta">Não
            </p>
			
			 <p>
                <label id="padrao">Coordenador</label><br>
                <input type="text" class="boxc" name="coordenador">
            </p>
			
			<p>
				<input type="submit" value="Cadastrar" id="acesso">
            </p>
			
	   </fieldset>	 
       </form>
	   </div>
	</body>
</html>