<?php
session_start();
include_once("conexao.php");
$title=$_POST ["title"];
$start=$_POST ["start"];
$end=$_POST ["end"];
$color=$_POST ["color"];
$result_cadastro="INSERT INTO agenda (title, start, end, color)
 Values('$title','$start','$end','$color')";
$resultado=mysqli_query($con, $result_cadastro);
if (mysqli_insert_id($con)){
     echo "<script>
                    alert('Evento cadastrado com sucesso!');
                    window.location.href='http://localhost/project/agenda.php';
                    </script>";
}else{
   echo "<script>
                    alert('O evento não foi cadastrado.');
                    window.location.href='http://localhost/project/agenda.php';
                    </script>";
}
?>