<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Cadastro Usuário</title>
		<link rel="stylesheet" type="text/css" href="css/cadastro_acao.css">
		<?php 
        session_start();
        if((!isset($_SESSION['matricula'])==true) and (!isset($_SESSION['senha'])==true))
        {
            unset($_SESSION['matricula']);
            unset($_SESSION['senha']);
                echo "<script>
                    alert('Acesso permitido somente a usuário logado');
                    window.location.href='login.php';
                    </script>";
        }
        $logado=$_SESSION['matricula'];
    ?> 
	</head>
	<body>
		<div id="menu">
			<ul>
				<img src="logo.png"/>
				<li><a href="http://localhost/project/cadastro_acao.php">Cadastrar Ação</a></li>
				<li><a href="http://localhost/project/result_acoes.php">Ações</a></li>
				<li><a href="http://localhost/project/agenda.php">Agenda</a></li>
				<li><a href="http://localhost/project/cadastro_usuario.php">Cadastrar usuários</a></li>
				<li><a href="http://localhost/project/login.php"><img src="sair-branco.png"/></a></li>
			</ul>
		</div>
		
		<h1>Cadastrar usuário</h1>	
		<div class="container">
		<form id="form" method="POST" action="cadastro.php">
		<fieldset>
			<?php
                        if(isset($_SESSION['mensagem'])){
                        echo $_SESSION['mensagem'];
                        unset ($_SESSION['mensagem']);
                        }
                    ?> 
		    <p>
                <label id="padrao">Matrícula</label><br>
                <input type="text" class="box" name= "matricula">
            </p>
			
			
            <p>
                <label id="padrao">Nome</label><br>
                <input type="text" class="box-name" name="nome">
            </p>
			
			<p>
				<label id="padrao">Cargo</label><br>
		        <select name="cargo">
					<option>Coordenador(a)</option>
                    <option>Assessor(a)</option>
					<option>Secretário(a)</option>
					<option>Estagiário(a)</option>
				</select>		
			</p>
			
			  
			<p>
                <label id="padrao">Senha</label><br>
                <input type="password" class="box" name="senha">
            </p>
			<p>
                <label id="padrao">Confirmar senha</label><br>
                <input type="password" class="box" name="confirmar_senha">
            </p>
             
             <div>
             	 
				<input type="submit" value="Cadastrar" id="acesso">
			
            </div>

	   </fieldset>	 
       </form>
	   </div>
	</body>
</html>