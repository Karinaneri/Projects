<?php
session_start();
include_once("conexao.php");
$matric=$_POST ["matricula"];
$password=$_POST['senha'];
$valida="SELECT * FROM cadastro_usuario WHERE matricula='$matric' AND senha='$password'";
$result=$con->query($valida);
if($result->num_rows>0){
    $_SESSION['matricula'] = $matric;
    $_SESSION['senha'] = $password;
    header('Location: http://localhost/project/cadastro_acao.php');
}
else{
    session_unset();
    session_destroy();
    echo "<script> 
        alert('Login ou senha incorreto');
        window.location.href = 'login.php';
        </script>";
      }
?>