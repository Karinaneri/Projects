<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Cadastro Evento</title>
		<link rel="stylesheet" type="text/css" href="css/cadastro_acao.css">
		<?php 
        session_start();
        if((!isset($_SESSION['matricula'])==true) and (!isset($_SESSION['senha'])==true))
        {
            unset($_SESSION['matricula']);
            unset($_SESSION['senha']);
                echo "<script>
                    alert('Acesso permitido somente a usuário logado');
                    window.location.href='login.php';
                    </script>";
        }
        $logado=$_SESSION['matricula'];
    ?> 
	</head>
	<body>
		<
		<h1>Cadastrar Evento</h1>	
		<div class="container">
		<form id="form" method="POST" action="cadastro_event.php">
		<fieldset>
			<?php
                        if(isset($_SESSION['mensagem'])){
                        echo $_SESSION['mensagem'];
                        unset ($_SESSION['mensagem']);
                        }
                    ?> 
		    <p>
                <label id="padrao">Titulo</label><br>
                <input type="text" class="box-name" name= "title">
            </p>
			
			
            <p>
                <label id="padrao">Início</label><br>
                <input type="datetime-local" class="box-name" name="start">
            </p>
			
			<p>
				<label id="padrao">Encerramento</label><br>
		         <input type="datetime-local" class="box-name" name="end">
			</p>
			
			  
			<p>
                <label id="padrao">Cor</label><br>
                <input type="text" class="box-name" name="color">
            </p>
			
             <div>
             	 
				<input type="submit" value="Enviar" id="acesso">
			
            </div>

	   </fieldset>	 
       </form>
	   </div>
	</body>
</html>