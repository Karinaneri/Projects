<?php
include_once("conexao.php");
$id_acao = ($_GET['id']);

$sql= "DELETE FROM cadastro_acao WHERE id= '$id_acao'";
$sql_query = $con->query($sql) or die ($con->error);


?>
