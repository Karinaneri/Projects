<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Sistema ENCCLA</title>
		 <link rel="stylesheet" type="text/css" href="css/login.css">
	</head>
	<body>
		<img src="logo.png">
		<div id="area">
		<form id="form" action="conta.php" method="POST">
			
		<fieldset>
			<p>
				<label for="username" id="usuario">Matrícula</label><br><br>
		        <input type="text" class="username" name="matricula">
			</p>
            <p><br>
                <label for="password"id="senha">Senha</label><br><br>
                <input type="password" class="password" name="senha">
            </p>
			 <p>
				 <input type="submit" id="acesso" value="Acessar">
            </p>
				   <a id= "new" href="#">Esqueceu a senha?</a>
       </fieldset>
        </form>
		</div>

	</body>
</html>