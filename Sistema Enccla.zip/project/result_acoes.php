<?php
include("conexao.php");
$consulta = "SELECT * FROM cadastro_acao";
$conn = $con->query($consulta) or die($conexao->error);
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset='utf-8'>
		<title>Agenda</title>
		<link rel="stylesheet" type="text/css" href="css/cadastro_acao.css">
		<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
		<?php 
        session_start();
        if((!isset($_SESSION['matricula'])==true) and (!isset($_SESSION['senha'])==true))
        {
            unset($_SESSION['matricula']);
            unset($_SESSION['senha']);
                echo "<script>
                    alert('Acesso permitido somente a usuário logado');
                    window.location.href='login.php';
                    </script>";
        }
        $logado=$_SESSION['matricula'];
    ?> 
	</head>
	<body>
		<div id="menu">
			
			<ul>
				<img src="logo.png"/>
				<li><a href="http://localhost/project/cadastro_acao.php">Cadastrar Ação</a></li>
				<li><a href="http://localhost/project/result_acoes.php">Ações</a></li>
				<li><a href="http://localhost/project/agenda.php">Agenda</a></li>
				<li><a href="http://localhost/project/cadastro_usuario.php">Cadastrar usuários</a></li>
				<li><a href="http://localhost/project/login.php"><img src="sair-branco.png"/></a></li>
			</ul>
		</div>
		<div class="f_tabela">
		<table id="cliTable" class="table table-striped table-bordered" style="width:100%">
                    <thead>
                        <tr class="titulo">
                            <td>Ano</td>
                            <td>Número</td>
                            <td>Título</td>
                            <td>Resultado</td>
                            <td>Objetivo estratégico</td>
                            <td>Temática</td>
                            <td>Envolve proposta normativa?</td>
                            <td>Coordenador</td>
                            <td>Alterar</td>

                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($dado = $conn->fetch_array()) { ?>
                            <tr>
                                <td><?php echo $dado['ano']; ?></td>
                                <td><?php echo $dado['numero']; ?></td>
                                <td><?php echo $dado['titulo']; ?></td>
                                <td><?php echo $dado['resultado']; ?></td>
                                <td><?php echo $dado['objetivo']; ?></td>
                                <td><?php echo $dado['tema']; ?></td>
                                <td><?php echo $dado['envolve_proposta']; ?></td>
                                <td><?php echo $dado['coordenador']; ?></td>
                                <td>
                                    <a href="#"> Editar</a>

                                    <a href="excluir.php?id=<?php echo $dado['id'];?>">Excluir</a>
                                </td>
                            <?php } ?>
                            </tr>
                    </tbody>
                </table>
            </div>
                 <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
                 <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
                 <script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.3.1.js"></script>
                 <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
                 <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
                 <script>
        $(document).ready(function() {
            $('#cliTable').DataTable({
                "language": {
                    "lengthMenu": "_MENU_ Quantidade por página ",
                    "zeroRecords": "Nenhum registro encontrado",
                    "info": "Página _PAGE_ de _PAGES_",
                    "infoEmpty": "Nenhum registro disponível",
                    "infoFiltered": "(filtrado de _MAX_ registros)"
                }
            });
        });
    </script>

	</body>
</html>
