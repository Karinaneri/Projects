-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 26-Nov-2021 às 04:11
-- Versão do servidor: 10.4.20-MariaDB
-- versão do PHP: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `admchurch`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `agenda`
--

CREATE TABLE `agenda` (
  `id` int(11) NOT NULL,
  `titulo` varchar(25) NOT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  `hora` time NOT NULL,
  `data` date NOT NULL,
  `local` varchar(30) NOT NULL,
  `status` varchar(15) NOT NULL,
  `endereco` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `agenda`
--

INSERT INTO `agenda` (`id`, `titulo`, `descricao`, `hora`, `data`, `local`, `status`, `endereco`) VALUES
(1, 'congresso', 'congresso avivando as nações', '19:00:00', '2021-11-30', 'Igreja Sede', 'Agendada', ''),
(2, 'congresso', 'congresso avivando as nações', '19:00:00', '2021-11-30', '<br />\r\n<b>Warning</b>:  Undef', 'Agendada', 'quadra 6'),
(3, 'amiversário', 'congresso avivando as nações', '20:00:00', '2021-11-23', '4', 'Concluída', 'aa'),
(4, 'congresso', 'congresso avivando as nações', '22:22:00', '2021-11-29', '2', 'Agendada', 's'),
(5, 'congresso', 'congresso avivando as nações', '22:22:00', '2021-11-30', '1', 'Agendada', 'z');

-- --------------------------------------------------------

--
-- Estrutura da tabela `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `telefone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `frequencias`
--

CREATE TABLE `frequencias` (
  `id` int(11) NOT NULL,
  `frequencia` varchar(35) NOT NULL,
  `dias` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `frequencias`
--

INSERT INTO `frequencias` (`id`, `frequencia`, `dias`) VALUES
(1, 'Uma Vez', 0),
(2, 'Diária', 1),
(3, 'Semanal', 7),
(4, 'Mensal', 30),
(5, 'Semestral', 180),
(6, 'Anual', 365);

-- --------------------------------------------------------

--
-- Estrutura da tabela `igrejas`
--

CREATE TABLE `igrejas` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(150) DEFAULT NULL,
  `obs` text DEFAULT NULL,
  `imagem` varchar(150) DEFAULT NULL,
  `pastor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `item`
--

CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `local`
--

CREATE TABLE `local` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `local`
--

INSERT INTO `local` (`id`, `nome`) VALUES
(1, 'Igreja Sede'),
(2, 'Outro Ministério'),
(3, 'Outros Locais'),
(4, 'A Definir');

-- --------------------------------------------------------

--
-- Estrutura da tabela `membresia`
--

CREATE TABLE `membresia` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cpf` varchar(20) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `foto` varchar(150) NOT NULL,
  `data_cad` date NOT NULL,
  `data_nasc` date DEFAULT NULL,
  `obs` varchar(500) DEFAULT NULL,
  `data_batismo` date DEFAULT NULL,
  `ministerio` varchar(50) NOT NULL,
  `ativo` varchar(5) NOT NULL,
  `igreja` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `membresia`
--

INSERT INTO `membresia` (`id`, `nome`, `email`, `cpf`, `telefone`, `endereco`, `foto`, `data_cad`, `data_nasc`, `obs`, `data_batismo`, `ministerio`, `ativo`, `igreja`) VALUES
(13, 'Karina Neri', 'karina@gmail.com', '032.222.222-22', '(11) 11111-1111', 'quadra 6', '19-11-2021-23-33-44-cliente.jpg', '2021-11-19', '2000-11-17', NULL, '2021-11-01', '2', 'Sim', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ministerio`
--

CREATE TABLE `ministerio` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `nome_url` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `ministerio`
--

INSERT INTO `ministerio` (`id`, `nome`, `descricao`, `nome_url`) VALUES
(1, 'Pastoral', '', 0),
(2, 'Louvor', '', 0),
(3, 'Diaconato', '', 0),
(4, 'Evangelismo', '', 0),
(5, 'Tesouraria', '', 0),
(6, 'Nenhum', '', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `movimentacoes`
--

CREATE TABLE `movimentacoes` (
  `id` int(11) NOT NULL,
  `tipo` varchar(20) NOT NULL,
  `movimento` varchar(25) NOT NULL,
  `descricao` varchar(50) NOT NULL,
  `valor` decimal(8,2) NOT NULL,
  `data` date NOT NULL,
  `usuario` int(11) NOT NULL,
  `id_mov` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ofertas`
--

CREATE TABLE `ofertas` (
  `id` int(11) NOT NULL,
  `membro` varchar(50) DEFAULT NULL,
  `valor` decimal(8,2) NOT NULL,
  `data` date NOT NULL,
  `usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagar`
--

CREATE TABLE `pagar` (
  `id` int(11) NOT NULL,
  `descricao` varchar(50) DEFAULT NULL,
  `valor` decimal(8,2) NOT NULL,
  `data` date NOT NULL,
  `vencimento` date NOT NULL,
  `usuario_cad` int(11) NOT NULL,
  `usuario_baixa` int(11) NOT NULL,
  `data_baixa` date DEFAULT NULL,
  `frequencia` int(11) NOT NULL,
  `pago` varchar(5) NOT NULL,
  `arquivo` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `patrimonios`
--

CREATE TABLE `patrimonios` (
  `id` int(11) NOT NULL,
  `codigo` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` varchar(500) NOT NULL,
  `estadocons` varchar(45) NOT NULL,
  `valor` decimal(10,0) NOT NULL,
  `foto` varchar(150) NOT NULL,
  `usuario_cad` int(11) NOT NULL,
  `data_cad` date NOT NULL,
  `igreja_cad` int(11) NOT NULL,
  `usuario_emprestou` int(11) NOT NULL,
  `data_emprestimo` date DEFAULT NULL,
  `ativo` varchar(5) NOT NULL,
  `obs` text DEFAULT NULL,
  `entrada` varchar(15) NOT NULL,
  `doador` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `patrimonios`
--

INSERT INTO `patrimonios` (`id`, `codigo`, `nome`, `descricao`, `estadocons`, `valor`, `foto`, `usuario_cad`, `data_cad`, `igreja_cad`, `usuario_emprestou`, `data_emprestimo`, `ativo`, `obs`, `entrada`, `doador`) VALUES
(2, 2, 'violão', 'violão corda de aço', 'Ótimo', '800', '22-11-2021-17-10-21-22-11-2021-17-02-44-05fb2cb44b32aea20d111fe29c67e21e.jpg', 65, '2021-11-22', 0, 0, NULL, 'Sim', 'Instrumento elétrico\r\n', 'Compra', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telefone` varchar(50) NOT NULL,
  `nomeigreja` varchar(255) NOT NULL,
  `senha` varchar(8) NOT NULL,
  `confirm` varchar(8) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `nivel` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id`, `nome`, `email`, `telefone`, `nomeigreja`, `senha`, `confirm`, `foto`, `nivel`) VALUES
(64, 'abc', 'kase@gmail.com', '(11) 22222-', 'eded', '12345678', '12345678', '', ''),
(65, 'Karina Neri', 'dna@gmail.com', '(11) 11111-', 'Fenix', '12345678', '12345678', '', ''),
(66, 'Karina Neri', 'f@gmail.com', '(11) 11111-', 'Sara', '12345678', '12345678', '', ''),
(67, 'Karina Neri', 'karina1333@gmail.com', '(11) 22222-', 'Sara', '12345678', '12345678', '', ''),
(68, 'Karina Neri', 'maria@gmail.com', '(33) 33333-3333', 'Universal do Reino', '12345678', '12345678', '', '');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `agenda`
--
ALTER TABLE `agenda`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `local`
--
ALTER TABLE `local`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `membresia`
--
ALTER TABLE `membresia`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `ministerio`
--
ALTER TABLE `ministerio`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `patrimonios`
--
ALTER TABLE `patrimonios`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `agenda`
--
ALTER TABLE `agenda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `item`
--
ALTER TABLE `item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `local`
--
ALTER TABLE `local`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `membresia`
--
ALTER TABLE `membresia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `ministerio`
--
ALTER TABLE `ministerio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `patrimonios`
--
ALTER TABLE `patrimonios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
