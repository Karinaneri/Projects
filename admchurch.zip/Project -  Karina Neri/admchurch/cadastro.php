
<?php 

@session_start();
include_once("conexao.php");
?> 

<html class="wide wow-animation" lang="en">
<head>
  <title>Cadastro</title>
  <link rel="icon" href="images/favicon.png" type="image/x-icon">
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <link rel="stylesheet" href="css/login.css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js"></script>

  <!------ Include the above in your HEAD tag ---------->

  <!-- login start -->
</head>
<body>

  <div class="wrapper fadeInDown">
    <div id="formContent">
      <!-- Tabs Titles -->

      <!-- Icon -->
      <a class="fadeIn first" href="index.php">
        <img src="images/logo-default-480x80.png"  id="icon" alt="Icon"  /></a>
      

      <!-- Login Form -->
      <form method="post">
        <input type="text" id="nome" class="fadeIn second" name="nome" placeholder="Nome Completo" required>
        <input type="email" id="email"  class="fadeIn second" name="email" placeholder="E-mail" required>
        <input type="text" id="telefone" name="telefone" class="fadeIn second" placeholder="Telefone" required>
        <input type="text" id="nomeigreja" class="fadeIn second" name="nomeigreja" placeholder="Nome da Igreja" required>
        <input type="password" id="senha" class="fadeIn second" name="senha" placeholder="Senha" minlength="8" required ><a class="pass" style=" margin-top: 0%; font-size: 10px; color: #0A573E;">A senha deve conter o mínimo de 8 caracteres!</a>
        <input type="password" id="confirm" class="fadeIn second" name="confirm" placeholder="Confirme a Senha" required>


        <div align="center" class="" id="mensagem"></div>

        <input type="submit" name="btn-cadastro" id="btn-cadastro" class="fadeIn fourth" value="Cadastrar">
        <div id="formFooter">
      <a class="underlineHover"  href="login.php">Realizar Login</a>
    </div>
      </form>



    </div>
  </div>

</body>
</html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>

<script src="js/mascaras.js"></script>

<script type="text/javascript">
  $(document).ready(function () {

    function validateEmail() {
      let regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      let validate = regex.test($('#email').val())

      return validate
    }

    $('#btn-cadastro').click(function (event) {
      event.preventDefault();
      
      if ($('#nome').val() === "") {
        return alert('Preencha o campo "Nome Completo"!')
      }
      
      if ($('#email').val() === "") {
        return alert('Preencha o campo "E-mail"!')
      }else if (validateEmail() === false) {
        return alert('E-mail Inválido');
      }

       if ($('#telefone').val() === "") {
        return alert('Preencha o campo "Telefone"!')
      } 
      
      if ($('#nomeigreja').val() === "") {
        return alert('Preencha o campo "Nome da Igreja"!')
      } 
      if ($('#senha').val() === "") {
        return alert('Preencha o campo "Senha"!')
      } 
      if ($('#senha').val().length < 8) {
        return alert('A senha deve conter o mínimo de 8 caracteres!');
      }
      if ($('#confirm').val() === "") {
        return alert('Preencha o campo "Confirme a Senha"!')
      } 


      $.ajax({
        url: "cadastrar.php",
        method: "post",
        data: $('form').serialize(),
        dataType: "text",
        success: function (mensagem) {

          $('#mensagem').removeClass()

          if (mensagem == 'Cadastrado com Sucesso!!') {

            $('#mensagem').addClass('text-success')

            document.getElementById('email').value = document.getElementById('email').value;

            document.getElementById('senha').value = document.getElementById('senha').value;

            $('#nome').val('')
            $('#email').val('')
            $('#telefone').val('')
            $('#nomeigreja').val('')
            $('#senha').val('')
            $('#confirm').val('')

            //$('#btn-fechar').click();
            //location.reload();
            console.log('object')
          } else {

            $('#mensagem').addClass('text-danger')
          }

          $('#mensagem').text(mensagem)

        },

      })
    })
  })
</script>