<?php 
date_default_timezone_set('America/Sao_Paulo');

$banco = "admchurch";
$servidor = "localhost";
$usuario = "root";
$senha = "";

$email_super_adm = "karinanerisantos@gmail.com";
$telefone_igreja_sistema = '(00) 00000-0000';

try {
	$pdo = new PDO("mysql:dbname=$banco;host=$servidor", "$usuario", "$senha");
} catch (Exception $e) {
	echo 'Erro ao conectar com o Banco de Dados! <br><br>' .$e;
}

 ?>