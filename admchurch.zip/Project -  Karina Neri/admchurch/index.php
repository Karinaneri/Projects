

<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
<head>
  <title>Home</title>
  <meta name="format-detection" content="telephone=no">
  <meta name="viewport" content="width=device-width height=device-height initial-scale=1.0 maximum-scale=1.0 user-scalable=0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta charset="utf-8">
  <link rel="icon" href="images/favicon.png" type="image/x-icon">
  <!-- Stylesheets-->
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Work+Sans:300,700,800%7COswald:300,400,500">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/fonts.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>
<body>
  <div class="page">
    <!-- Page Header-->
    <header class="section page-header" data-type="anchor">
      <!-- RD Navbar-->
      <div class="rd-navbar-wrap">
        <nav class="rd-navbar rd-navbar-minimal" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-fixed" data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-fixed" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px" data-xxl-stick-up-offset="46px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
          <div class="rd-navbar-main-outer">
            <div class="rd-navbar-main">
              <!-- RD Navbar Panel-->
              <div class="rd-navbar-panel">
                <!-- RD Navbar Toggle-->
                <button class="rd-navbar-toggle" data-rd-navbar-toggle="#rd-navbar-nav-wrap-1"><span></span></button>
                <!-- RD Navbar Brand--><a class="rd-navbar-brand" href="index.php"><img src="images/logo-default-480x80.png" width="240" height="40" alt=""></a>
              </div>
              <div class="rd-navbar-main-element">
                <div class="rd-navbar-nav-wrap" id="rd-navbar-nav-wrap-1">
                  <!-- RD Navbar Nav-->
                  <ul class="rd-navbar-nav">
                    <li class="rd-nav-item active"><a class="rd-nav-link" href="#home" >Home</a>
                    </li>
                    <li class="rd-nav-item"><a class="rd-nav-link" href="#services">Funcionalidades</a>
                    </li>
                    <li class="rd-nav-item"><a class="rd-nav-link" href="#about-us">Sobre</a>
                    </li>
                    <li class="rd-nav-item"><a target="_blank" class="rd-nav-link" href="cadastro.php">Cadastre-se</a>
                    </li>                      
                    <li class="rd-nav-item"><a class="rd-nav-link" href="#contact-us">Fale conosco</a>
                    </li>
                    <li class="rd-nav-item"><a target="_blank" class="rd-nav-link" href="login.php">Login</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>
    <div class="swiper-container swiper-slider swiper-slider-minimal" id="home" data-loop="true" data-slide-effect="fade" data-autoplay="3500" data-simulate-touch="true">
      <div class="swiper-wrapper">
        <div class="swiper-slide" data-slide-bg="images/slider-minimal-slide-1-1920x888.jpg">
          <div class="swiper-slide-caption">
            <div class="container">
              <div class="swiper-slide-text">
                <div class="text-large">Igreja inteligente, digital e integrada</div>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide" data-slide-bg="images/slider-minimal-slide-2-1920x888.jpg">
          <div class="swiper-slide-caption">
            <div class="container">
              <div class="swiper-slide-text">
                <div class="text-large">Gestão administrativa completa</div>
              </div>
            </div>
          </div>
        </div>
        <div class="swiper-slide" data-slide-bg="images/slider-minimal-slide-3-1920x888.jpg">
          <div class="swiper-slide-caption">
            <div class="container">
              <div class="swiper-slide-text">
                <div class="text-large">tudo o que a sua igreja precisa em um só lugar</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-pagination-outer container">
        <div class="swiper-pagination swiper-pagination-modern swiper-pagination-marked" data-index-bullet="true"></div>
      </div>
    </div>
    <!-- Our Services-->
    <section class="section section-lg text-center" id="services" data-type="anchor">
      <div class="container">
        <h3 class="wow-outer"><span class="wow slideInUp">Funcionalidades</span></h3>
        <p class="wow-outer"><span class="text-width-1 wow slideInDown"></span></p>
        <div class="row row-50 row-xxl-70 offset-top-2">
          <div class="col-sm-6 col-md-4 col-lg-3 wow-outer">
            <!-- Box Light-->
            <article class="box-light wow slideInLeft">
              <div class="box-light-icon fl-bigmug-line-weekly15"></div>
              <h4 class="box-light-title">Agenda</h4>
              <p>Tenha total controle dos eventos marcados na igreja para uma maior organização.</p>
            </article>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 wow-outer">
            <!-- Box Light-->
            <article class="box-light wow slideInLeft" data-wow-delay=".05s">
              <div class="box-light-icon fl-bigmug-line-user144"></div>
              <h4 class="box-light-title">Cadastro de Membros</h4>
              <p>Cadastre os novos membros da sua igreja.</p>
            </article>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 wow-outer">
            <!-- Box Light-->
            <article class="box-light wow slideInLeft" data-wow-delay=".1s">
              <div class="box-light-icon fl-bigmug-line-file69"></div>
              <h4 class="box-light-title">Escalas</h4>
              <p>Tenha o controle das escalas dos membros da igreja em seus respectivos ministérios.</p>
            </article>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 wow-outer">
            <!-- Box Light-->
            <article class="box-light wow slideInLeft" data-wow-delay=".15s">
              <div class="box-light-icon fl-bigmug-line-wallet26"></div>
              <h4 class="box-light-title">Financeiro</h4>
              <p>Saiba como está a saúde financeira da sua igreja. Controle financeiro completo.</p>
            </article>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-3 wow-outer">
            <!-- Box Light-->
            <article class="box-light wow slideInLeft">
              <div class="box-light-icon fl-bigmug-line-cube29"></div>
              <h4 class="box-light-title">Patrimônio</h4>
              <p>Aqui você poderá realizar todo o controle do patrimônio da igreja para obter uma melhor conservação e para que os bens não sejam perdidos.</p>
            </article>
          </div>
        </div>
      </div>
    </section>
    <!-- A Few Words About Us-->
    <section class="section section-lg bg-gray-100" id="about-us" data-type="anchor">
      <div class="container">
        <div class="row row-50 justify-content-center justify-content-lg-between">
          <div class="col-md-10 col-lg-6 col-xl-5">
            <h3 class="wow-outer"><span class="wow slideInDown">Sobre</span></h3>
            <p class="wow-outer"><span class="wow slideInDown" data-wow-delay=".05s"></span>O Administer Church foi idealizado para ser um ambiente que permite o getenciamento das diversas áreas da sua igreja. A aplicação visa facilitar as atividades cotidianas da instituição e garantir a segurança de dados importantes para a sua igreja. Tudo isso online, com segurança e confiabilidade.</p>
            <div class=""><a class="" data-wow-delay=".1s" href="#"></a></div>
            </div>
            <div class="col-md-10 col-lg-6 wow-outer"><img class="img-responsive wow slideInRight" src="images/large-features-2-570x368.jpg" alt="" width="570" height="368"/>
            </div>
          </div>
        </div>
      </section>

      

      <!-- Wide CTA-->
      <section class="section section-md bg-primary-gradient text-center">
        <div class="container">
          <div class="box-cta-1">
            <h3 class="wow-outer"><span class="wow slideInRight">A plataforma de gestão ideal <span class="font-weight-bold">para sua igreja!</span></span></h3>
            <div class="wow-outer button-outer"><a class="button button-lg button-primary button-winona wow slideInLeft" href="cadastro.php">Cadastre-se</a></div>
          </div>
        </div>
      </section>

      <!-- Contact Us-->
      <section class="section bg-gray-100" id="contact-us" data-type="anchor">
        <div class="range justify-content-xl-between">
          <div class="cell-xl-6 align-self-center container">
            <div class="row">
              <div class="col-lg-9 cell-inner">
                <div class="section-lg">
                  <h3 class="wow-outer"><span class="wow slideInDown">Fale conosco<span></h3>
                    <!-- RD Mailform-->
                    <form class="rd-form rd-mailform" data-form-output="form-output-global" data-form-type="contact" method="post" action="enviar.php">
                      <div class="row row-10">
                        <div class="col-md-6 wow-outer">
                          <div class="form-wrap wow fadeSlideInUp">
                            <label class="form-label-outside" for="contact-first-name">Nome</label>
                            <input class="form-input" id="contact-first-name" type="text"  placeholder: "Nome e Sobrenome" name="nome" data-constraints="@Required">
                          </div>
                        </div>
                        <div class="col-md-6 wow-outer">
                          <div class="form-wrap wow fadeSlideInUp">
                            <label class="form-label-outside" for="contact-phone">WhatsApp</label>
                            <input class="form-input" id="telefone" type="text" name="telefone" data-constraints="@PhoneNumber @Required">
                          </div>
                        </div>
                        <div class="col-md-6 wow-outer">
                          <div class="form-wrap wow fadeSlideInUp">
                            <label class="form-label-outside" for="contact-email">E-mail</label>
                            <input class="form-input" id="contact-email" type="email" name="email" data-constraints="@Email @Required">
                          </div>
                        </div>
                        <div class="col-12 wow-outer">
                          <div class="form-wrap wow fadeSlideInUp">
                            <label class="form-label-outside" for="contact-message">Mensagem</label>
                            <textarea class="form-input" id="contact-message" name="message" data-constraints="@Required"></textarea>
                          </div>
                        </div>
                      </div>
                      <div class="group group-middle">
                        <div class="wow-outer">
                          <button class="button button-primary button-winona wow slideInRight" type="submit">Enviar</button>
                        </div>

                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- Page Footer-->
        <footer class="section footer-linked bg-gray-700">
          <div class="footer-linked-main">
            <div class="container">
              <div class="row row-50">
                <div class="col-lg-8">
                  <h4>Redes Sociais</h4>
                  <hr class="offset-right-1">
                  <div class="row row-20">
                    <div class="col-6 col-sm-3">
                      <ul class="list list-xs">
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Twitter</a></li>
                        <li><a href="#">Instagram</a></li>
                        <li><a href="#">LinkedIn</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-md-7 col-lg-4">
                  <h4>Contato</h4>
                  <ul>
                <li class="object-inline"><span class="icon icon-md mdi mdi-email text-gray-700"></span><a class="link-default" href="mailto:#">administer@church.com</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-linked-aside">
        <div class="container">
          <!-- Rights-->
          <p class="rights"><span>&copy;&nbsp;</span><span class="copyright-year"></span><span>&nbsp;</span><span>Karina Neri dos Santos</span></p>
        </div>
      </div>
    </footer>
  </div>

  <!-- Global Mailform Output-->
  <div class="snackbars" id="form-output-global"></div>
  <!-- Javascript-->
  <script src="js/core.min.js"></script>
  <script src="js/script.js"></script>
  <!-- coded by ragnar-->
</body>
</html>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>

<script src="js/mascaras.js"></script>