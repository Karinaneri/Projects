<?php
require_once("../conexao.php");
$nome = $_POST['nome_usu'];
$telefone = $_POST['telefone_usu'];
$email = $_POST['email_usu'];
$nomeigreja =  $_POST['nomeigreja_usu'];
$id = $_POST['id_usu'];

$query = $pdo->query("SELECT * FROM usuario where id = $id");
$res = $query->fetchAll(PDO::FETCH_ASSOC);
$nome_antigo = $res[0]['nome'];

$email_antigo = $res[0]['email'];
$nivel_usu = $res[0]['nivel'];
$id_pessoa = $res[0]['id'];



if($email_antigo != $email){
	$query = $pdo->query("SELECT * FROM usuario where email = '$email'");
	$res = $query->fetchAll(PDO::FETCH_ASSOC);
	
	if(@count($res) > 0){
		echo 'O Email já está cadastrado!';
		exit();
	}
}

$query = $pdo->prepare("UPDATE usuario SET nome = :nome, telefone = :telefone, email = :email, nomeigreja = :nomeigreja where id = '$id'");

$query->bindValue(":nome", "$nome");
$query->bindValue(":telefone", "$telefone");
$query->bindValue(":email", "$email");
$query->bindValue(":nomeigreja", "$nomeigreja");

$query->execute();
	echo 'Salvo com Sucesso';


 ?>