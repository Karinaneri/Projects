<?php 

include_once("conexao.php");

$nome = $_POST['nome'];
$telefone = $_POST['telefone'];
$celular = $_POST['celular'];
$email = $_POST['email'];
$razao = $_POST['razao'];
$cnpj = $_POST['cnpj'];
$cep = $_POST['cep'];
$senha = $_POST['senha'];


//CONSULTA PARA TRAZER O CPF E EMAIL CASO JÁ EXISTA NO BANCO
$res = $pdo->query("SELECT * from distribuidoras where usuario = '$email'");
$dados = $res->fetchAll(PDO::FETCH_ASSOC);
$linhas = count($dados);
if($linhas > 0){
    $email_recup = $dados[0]['usuario'];
}



$res = $pdo->prepare("INSERT into distribuidoras (nome, telefone, celular, usuario, razao, cnpj, cep, senha) values (:nome, :telefone, :celular, :usuario, :razao, :cnpj, :cep, :senha)");

    $res->bindValue(":nome", $nome);
    $res->bindValue(":telefone", $telefone);
    $res->bindValue(":celular", $celular);
    $res->bindValue(":usuario", $email);
    $res->bindValue(":razao", $razao);
    $res->bindValue(":cnpj", $cnpj);
    $res->bindValue(":cep", $cep);
    $res->bindValue(":senha", $senha);


    $res->execute();

    echo 'Cadastrado com Sucesso!';


 ?>