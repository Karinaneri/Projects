<?php 

include_once("conexao.php");

if(isset($_POST['email2']) and $_POST['email2'] != ''){
$email_rec = $_POST['email2'];
}
?>


<head>
	<title>CADASTRO FINDGÁS</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>


<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</head>
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form p-l-55 p-r-55 p-t-178" method="post" action="cadastro-revend.php">
					<span class="login100-form-title">
						CADASTRE-SE
						<a class="login100-form-subtitle"></br>(Apenas revendedores autorizados pela ANP)</a>
					</span>

					<div class="wrap-input100 validate-input m-b-16" data-validate="Entre com seu nome">
						<input class="input100" type="text" name="nome" placeholder="Nome do Responsável da Revenda">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-16" data-validate = "Entre com seu telefone fixo">
						<input class="input100" type="text" name="telefone" placeholder="Telefone Fixo">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-16" data-validate = "Entre com seu telefone celular">
						<input class="input100" type="text" name="celular" placeholder="Telefone Celular">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-16" data-validate = "Entre com seu e-mail">
						<input class="input100" type="email" name="email" placeholder="E-mail">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-16" data-validate = "Entre com sua razão social">
						<input class="input100" type="text" name="razao" placeholder="Razão Social">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-16" data-validate = "Entre com seu CNPJ">
						<input class="input100" type="text" name="cnpj" placeholder="CNPJ">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-16" data-validate = "Entre com seu CEP">
						<input class="input100" type="text" name="cep" placeholder="CEP">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-16" data-validate = "Please enter password">
						<input class="input100" type="password" name="senha" placeholder="Senha">
						<span class="focus-input100"></span>
					</div>

					<div class="container-login100-form-btn">
						<button  class="login100-form-btn" name="btn-cadastro">
							Cadastrar
						</button>
					</div>
                </form>
				</div>
				</div>
				</div>

</body>
