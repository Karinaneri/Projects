<?php 

$email_adm = 'karinanerisantos@gmail.com';
$url_site = 'http://localhost/starter-template/';


//DADOS PARA CONEXÃO COM BD LOCAL
$banco = 'findgas';
$host = 'localhost';
$usuario = 'root';
$senha = '';

 ?>