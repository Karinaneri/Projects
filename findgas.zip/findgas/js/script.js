
mapboxgl.accessToken = 'pk.eyJ1Ijoid2V2ZXJzb25uZXJpIiwiYSI6ImNrZzc2YmQ4NjA0YjIyeG10MGliamtxeTUifQ._xfPR9pG0kvxN0pjL1z22g';
var map = new mapboxgl.Map({
  container: 'map',
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [-79.4512, 43.6568],
  zoom: 13
});

// Add the control to the map.
var geocoder = new MapboxGeocoder({
  accessToken: mapboxgl.accessToken,
  mapboxgl: mapboxgl
});

document.getElementById('geocoder').appendChild(geocoder.onAdd(map));
